function getYear() {
    return new Date().getFullYear();
}